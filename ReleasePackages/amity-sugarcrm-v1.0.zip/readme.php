<?php

return str_replace('#', '', file_get_contents(__DIR__ . '/README.md'));