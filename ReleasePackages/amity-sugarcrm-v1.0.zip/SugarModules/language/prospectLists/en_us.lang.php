<?php 
$mod_strings['LBL_EXPORT_TO_AMITY_BUTTON_LABEL'] = 'Export To amity';
$mod_strings['LBL_EXPORT_TO_AMITY_CONFIRMATION'] = 'Do you really want to export this Target List to amity?';
$mod_strings['ERR_AMITY_CONNECTION_CREDENTIALS'] = 'Invalid credentials!';
$mod_strings['LBL_SUCCESS_EXPORT_TO_AMITY'] = 'Target List successfully exported to amity.';
$mod_strings['LBL_FAIL_EXPORT_TO_AMITY'] = 'List export to amity failed.';