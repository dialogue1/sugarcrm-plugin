<?php 
$mod_strings['LBL_EXPORT_TO_AMITY_BUTTON_LABEL'] = 'Export nach amity';
$mod_strings['LBL_EXPORT_TO_AMITY_CONFIRMATION'] = 'Möchten Sie die Marketingliste in amity exportieren?';
$mod_strings['ERR_AMITY_CONNECTION_CREDENTIALS'] = 'Invalid credentials!';
$mod_strings['LBL_SUCCESS_EXPORT_TO_AMITY'] = 'Target List successfully exported to amity.';
$mod_strings['LBL_FAIL_EXPORT_TO_AMITY'] = 'List export to amity failed.';
